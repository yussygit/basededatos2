<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "yussy";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["procedimiento"])) {
    $procedimiento = $_POST["procedimiento"];
    
    $stmt = null;
    
    switch ($procedimiento) {
        case "InsertarCliente":
            $stmt = $conn->prepare("CALL InsertarCliente(?, ?, ?)");
            $stmt->bind_param("sss", $_POST["nombre"], $_POST["direccion"], $_POST["telefono"]);
            break;
        case "InsertarProducto":
            $stmt = $conn->prepare("CALL InsertarProducto(?, ?, ?, ?, ?)");
            $stmt->bind_param("sdiii", $_POST["nombre"], $_POST["precio"], $_POST["stock"], $_POST["id_categoria"], $_POST["id_proveedor"]);
            break;
        case "InsertarVenta":
            $stmt = $conn->prepare("CALL InsertarVenta(?, ?, ?)");
            $stmt->bind_param("isd", $_POST["id_cliente"], $_POST["fecha"], $_POST["total"]);
            break;
        case "ActualizarPrecioProducto":
            $stmt = $conn->prepare("CALL ActualizarPrecioProducto(?, ?)");
            $stmt->bind_param("id", $_POST["id_producto"], $_POST["nuevo_precio"]);
            break;
        case "ActualizarDireccionCliente":
            $stmt = $conn->prepare("CALL ActualizarDireccionCliente(?, ?)");
            $stmt->bind_param("is", $_POST["id_cliente"], $_POST["nueva_direccion"]);
            break;
        case "EliminarCliente":
            $stmt = $conn->prepare("CALL EliminarCliente(?)");
            $stmt->bind_param("i", $_POST["id_cliente"]);
            break;
        case "EliminarProducto":
            $stmt = $conn->prepare("CALL EliminarProducto(?)");
            $stmt->bind_param("i", $_POST["id_producto"]);
            break;
        case "ObtenerTotalVentasCliente":
            $stmt = $conn->prepare("CALL ObtenerTotalVentasCliente(?, @total)");
            $stmt->bind_param("i", $_POST["id_cliente"]);
            $stmt->execute();
            $result = $conn->query("SELECT @total AS total");
            break;
        case "ObtenerStockProducto":
            $stmt = $conn->prepare("CALL ObtenerStockProducto(?, @stock)");
            $stmt->bind_param("i", $_POST["id_producto"]);
            $stmt->execute();
            $result = $conn->query("SELECT @stock AS stock");
            break;
        case "VerificarYActualizarStock":
            $stmt = $conn->prepare("CALL VerificarYActualizarStock(?, ?, @stock_restante)");
            $stmt->bind_param("ii", $_POST["id_producto"], $_POST["cantidad_vendida"]);
            $stmt->execute();
            $result = $conn->query("SELECT @stock_restante AS stock_restante");
            break;
        case "ObtenerVentasPorFecha":
            $stmt = $conn->prepare("CALL ObtenerVentasPorFecha(?, ?)");
            $stmt->bind_param("ss", $_POST["fecha_inicio"], $_POST["fecha_fin"]);
            break;
        case "AplicarDescuentoVenta":
            $stmt = $conn->prepare("CALL AplicarDescuentoVenta(?, ?, @nuevo_total)");
            $stmt->bind_param("id", $_POST["id_venta"], $_POST["descuento_porcentaje"]);
            $stmt->execute();
            $result = $conn->query("SELECT @nuevo_total AS nuevo_total");
            break;
        default:
            die("Procedimiento no reconocido.");
    }

    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result(); 
    }

    if (isset($result) && $result !== false) {
        if ($result->num_rows > 0) {
            echo "<table border='1'><tr>";
            while ($field = $result->fetch_field()) {
                echo "<th>" . htmlspecialchars($field->name) . "</th>";
            }
            echo "</tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>" . htmlspecialchars($value) . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No se encontraron resultados.</p>";
        }
    } else {
        echo "<p>Procedimiento ejecutado con éxito.</p>";
    }
}
?>






<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "yussy";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["procedimiento"])) {
    $procedimiento = $_POST["procedimiento"];
    
    $stmt = null;
    
    switch ($procedimiento) {
        case "InsertarCliente":
            $stmt = $conn->prepare("CALL InsertarCliente(?, ?, ?)");
            $stmt->bind_param("sss", $_POST["nombre"], $_POST["direccion"], $_POST["telefono"]);
            break;
        case "InsertarProducto":
            $stmt = $conn->prepare("CALL InsertarProducto(?, ?, ?, ?, ?)");
            $stmt->bind_param("sdiii", $_POST["nombre"], $_POST["precio"], $_POST["stock"], $_POST["id_categoria"], $_POST["id_proveedor"]);
            break;
        case "InsertarVenta":
            $stmt = $conn->prepare("CALL InsertarVenta(?, ?, ?)");
            $stmt->bind_param("isd", $_POST["id_cliente"], $_POST["fecha"], $_POST["total"]);
            break;
        case "ActualizarPrecioProducto":
            $stmt = $conn->prepare("CALL ActualizarPrecioProducto(?, ?)");
            $stmt->bind_param("id", $_POST["id_producto"], $_POST["nuevo_precio"]);
            break;
        case "ActualizarDireccionCliente":
            $stmt = $conn->prepare("CALL ActualizarDireccionCliente(?, ?)");
            $stmt->bind_param("is", $_POST["id_cliente"], $_POST["nueva_direccion"]);
            break;
        case "EliminarCliente":
            $stmt = $conn->prepare("CALL EliminarCliente(?)");
            $stmt->bind_param("i", $_POST["id_cliente"]);
            break;
        case "EliminarProducto":
            $stmt = $conn->prepare("CALL EliminarProducto(?)");
            $stmt->bind_param("i", $_POST["id_producto"]);
            break;
        case "ObtenerTotalVentasCliente":
            $stmt = $conn->prepare("CALL ObtenerTotalVentasCliente(?, @total)");
            $stmt->bind_param("i", $_POST["id_cliente"]);
            $stmt->execute();
            $result = $conn->query("SELECT @total AS total");
            break;
        case "ObtenerStockProducto":
            $stmt = $conn->prepare("CALL ObtenerStockProducto(?, @stock)");
            $stmt->bind_param("i", $_POST["id_producto"]);
            $stmt->execute();
            $result = $conn->query("SELECT @stock AS stock");
            break;
        case "VerificarYActualizarStock":
            $stmt = $conn->prepare("CALL VerificarYActualizarStock(?, ?, @stock_restante)");
            $stmt->bind_param("ii", $_POST["id_producto"], $_POST["cantidad_vendida"]);
            $stmt->execute();
            $result = $conn->query("SELECT @stock_restante AS stock_restante");
            break;
        case "ObtenerVentasPorFecha":
            $stmt = $conn->prepare("CALL ObtenerVentasPorFecha(?, ?)");
            $stmt->bind_param("ss", $_POST["fecha_inicio"], $_POST["fecha_fin"]);
            break;
        case "AplicarDescuentoVenta":
            $stmt = $conn->prepare("CALL AplicarDescuentoVenta(?, ?, @nuevo_total)");
            $stmt->bind_param("id", $_POST["id_venta"], $_POST["descuento_porcentaje"]);
            $stmt->execute();
            $result = $conn->query("SELECT @nuevo_total AS nuevo_total");
            break;
        default:
            die("Procedimiento no reconocido.");
    }

    if ($stmt) {
        $stmt->execute();
        $result = $stmt->get_result(); 
    }

    if (isset($result) && $result !== false) {
        if ($result->num_rows > 0) {
            echo "<table border='1'><tr>";
            while ($field = $result->fetch_field()) {
                echo "<th>" . htmlspecialchars($field->name) . "</th>";
            }
            echo "</tr>";

            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                foreach ($row as $value) {
                    echo "<td>" . htmlspecialchars($value) . "</td>";
                }
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No se encontraron resultados.</p>";
        }
    } else {
        echo "<p>Procedimiento ejecutado con éxito.</p>";
    }
}
?>





-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-03-2025 a las 01:43:04
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `yussy`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarDireccionCliente` (IN `p_id_cliente` INT, IN `p_nueva_direccion` VARCHAR(255))   BEGIN
    UPDATE Clientes 
    SET direccion = p_nueva_direccion 
    WHERE id_cliente = p_id_cliente;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ActualizarPrecioProducto` (IN `p_id_producto` INT, IN `p_nuevo_precio` DECIMAL(10,2))   BEGIN
    UPDATE Productos 
    SET precio = p_nuevo_precio 
    WHERE id_producto = p_id_producto;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `AplicarDescuentoVenta` (IN `p_id_venta` INT, IN `p_descuento_porcentaje` DECIMAL(5,2), OUT `p_nuevo_total` DECIMAL(10,2))   BEGIN
    DECLARE v_total_actual DECIMAL(10,2);
    
    -- Obtener el total de la venta
    SELECT total INTO v_total_actual 
    FROM Ventas 
    WHERE id_venta = p_id_venta;
    
    -- Calcular el nuevo total con descuento
    SET p_nuevo_total = v_total_actual - (v_total_actual * p_descuento_porcentaje / 100);
    
    -- Actualizar el total en la tabla Ventas
    UPDATE Ventas 
    SET total = p_nuevo_total 
    WHERE id_venta = p_id_venta;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarCliente` (IN `p_id_cliente` INT)   BEGIN
    DELETE FROM Clientes WHERE id_cliente = p_id_cliente;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `EliminarProducto` (IN `p_id_producto` INT)   BEGIN
    DELETE FROM Productos WHERE id_producto = p_id_producto;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarCliente` (IN `p_nombre` VARCHAR(100), IN `p_direccion` VARCHAR(255), IN `p_telefono` VARCHAR(15))   BEGIN
    INSERT INTO Clientes (nombre, direccion, telefono) 
    VALUES (p_nombre, p_direccion, p_telefono);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarProducto` (IN `p_nombre` VARCHAR(100), IN `p_precio` DECIMAL(10,2), IN `p_stock` INT, IN `p_id_categoria` INT, IN `p_id_proveedor` INT)   BEGIN
    INSERT INTO Productos (nombre, precio, stock, id_categoria, id_proveedor) 
    VALUES (p_nombre, p_precio, p_stock, p_id_categoria, p_id_proveedor);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `InsertarVenta` (IN `p_id_cliente` INT, IN `p_fecha` DATE, IN `p_total` DECIMAL(10,2))   BEGIN
    INSERT INTO Ventas (id_cliente, fecha, total) 
    VALUES (p_id_cliente, p_fecha, p_total);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerStockProducto` (IN `p_id_producto` INT, OUT `p_stock_actual` INT)   BEGIN
    SELECT stock INTO p_stock_actual 
    FROM Productos 
    WHERE id_producto = p_id_producto;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerTotalVentasCliente` (IN `p_id_cliente` INT, OUT `p_total_ventas` DECIMAL(10,2))   BEGIN
    SELECT SUM(total) INTO p_total_ventas 
    FROM Ventas 
    WHERE id_cliente = p_id_cliente;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `ObtenerVentasPorFecha` (IN `p_fecha_inicio` DATE, IN `p_fecha_fin` DATE)   BEGIN
    SELECT * FROM Ventas 
    WHERE fecha BETWEEN p_fecha_inicio AND p_fecha_fin;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `VerificarYActualizarStock` (IN `p_id_producto` INT, IN `p_cantidad_vendida` INT, OUT `p_stock_restante` INT)   BEGIN
    DECLARE v_stock_actual INT;
    
    -- Obtener stock actual
    SELECT stock INTO v_stock_actual 
    FROM Productos 
    WHERE id_producto = p_id_producto;
    
    -- Verificar si hay suficiente stock
    IF v_stock_actual >= p_cantidad_vendida THEN
        UPDATE Productos 
        SET stock = stock - p_cantidad_vendida 
        WHERE id_producto = p_id_producto;
        
        SET p_stock_restante = v_stock_actual - p_cantidad_vendida;
    ELSE
        SET p_stock_restante = -1;  -- Indica que no hay suficiente stock
    END IF;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id_categoria`, `nombre`) VALUES
(1, 'Lácteos'),
(2, 'Carnes'),
(3, 'Bebidas'),
(4, 'Panadería'),
(5, 'pescado'),
(6, 'huevos'),
(7, 'granos'),
(8, 'cereales'),
(9, 'verduras'),
(10, 'cafe');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre`, `direccion`, `telefono`) VALUES
(1, 'Carlos López', 'calle 23', '111222333'),
(2, 'Ana Torres', 'jardin', '444555666'),
(3, 'Carlos Pérez', 'Calle 10 #23-45, Bogotá', '3112233445'),
(4, 'Ana Gómez', 'Carrera 15 #34-67, Medellín', '3123344556'),
(5, 'Luis Rodríguez', 'Av. Siempre Viva 742, Lima', '3154455667'),
(6, 'María Torres', 'Calle 50 #12-34, Buenos Aires', '3165566778'),
(7, 'Jorge Herrera', 'Calle 7 #45-89, Santiago', '3176677889'),
(8, 'Lucía Ramírez', 'Carrera 8 #90-12, Quito', '3187788990'),
(9, 'Ricardo López', 'Calle 22 #67-45, Ciudad de México', '3198899001'),
(10, 'Paola Castillo', 'Av. Reforma 123, Ciudad de México', '3209900112'),
(11, 'Fernando Álvarez', 'Calle 33 #14-56, Caracas', '3210011223'),
(12, 'Camila Martínez', 'Carrera 40 #78-90, Montevideo', '3221122334'),
(13, 'Daniel Ríos', 'Av. Central 567, Asunción', '3232233445'),
(14, 'Sofía Medina', 'Calle 12A #89-76, San José', '3243344556'),
(15, 'José Ramírez', 'Carrera 21 #34-67, Managua', '3254455667'),
(16, 'Andrea Fernández', 'Av. del Libertador 321, Buenos Aires', '3265566778'),
(17, 'Pablo Vargas', 'Calle 9 #45-21, La Paz', '3276677889'),
(18, 'Diana Soto', 'Carrera 14 #78-56, Tegucigalpa', '3287788990'),
(19, 'Cristian Mendoza', 'Av. 5 de Mayo 123, Ciudad de México', '3298899001'),
(20, 'Natalia Ruiz', 'Calle 45 #67-89, San Salvador', '3309900112'),
(21, 'Oscar Gutiérrez', 'Carrera 23 #12-34, Guatemala', '3310011223'),
(22, 'Isabella Castro', 'Av. Bolívar 456, Caracas', '3321122334'),
(23, 'Hugo Ortega', 'Calle 67 #45-12, Santo Domingo', '3332233445'),
(24, 'Valeria Peña', 'Carrera 8A #23-56, Panamá', '3343344556'),
(25, 'Rodrigo Salazar', 'Calle 13 #90-78, San Juan', '3354455667'),
(26, 'Laura Vargas', 'Av. Colón 678, Lima', '3365566778'),
(27, 'Martín Silva', 'Calle 18 #34-56, Bogotá', '3376677889'),
(28, 'Elena Contreras', 'Carrera 10 #45-89, Quito', '3387788990'),
(29, 'Gustavo Espinoza', 'Av. Roosevelt 987, Montevideo', '3398899001'),
(30, 'Marta León', 'Calle 21 #78-34, Buenos Aires', '3409900112'),
(31, 'Javier Benítez', 'Carrera 9 #56-12, Caracas', '3410011223'),
(32, 'Renata Paredes', 'Calle 33 #45-78, Asunción', '3421122334');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalleventas`
--

CREATE TABLE `detalleventas` (
  `id_detalle` int(11) NOT NULL,
  `id_venta` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalleventas`
--

INSERT INTO `detalleventas` (`id_detalle`, `id_venta`, `id_producto`, `cantidad`, `subtotal`) VALUES
(1, 1, 2, 1, 10.00),
(2, 1, 3, 2, 4.00),
(3, 2, 4, 2, 2.40),
(1, 3, 5, 3, 7500.00),
(2, 3, 10, 2, 19800.00),
(3, 4, 15, 4, 6000.00),
(4, 4, 20, 1, 32000.00),
(5, 5, 25, 6, 21000.00),
(6, 5, 30, 2, 24000.00),
(7, 6, 35, 5, 9000.00),
(8, 6, 40, 3, 30000.00),
(9, 7, 7, 2, 9600.00),
(10, 7, 12, 1, 6500.00),
(11, 8, 17, 4, 9200.00),
(12, 8, 22, 2, 30800.00),
(13, 9, 27, 3, 7500.00),
(14, 9, 32, 2, 6000.00),
(15, 10, 37, 4, 10000.00),
(16, 10, 42, 2, 14000.00),
(17, 11, 6, 3, 14400.00),
(18, 11, 11, 1, 11800.00),
(19, 12, 16, 2, 7600.00),
(20, 12, 21, 3, 32700.00),
(21, 13, 26, 4, 19200.00),
(22, 13, 29, 2, 6000.00),
(23, 14, 34, 5, 14000.00),
(24, 14, 39, 3, 16500.00),
(25, 15, 9, 3, 37500.00),
(26, 15, 14, 2, 4400.00),
(27, 16, 19, 4, 16800.00),
(28, 16, 24, 1, 18000.00),
(29, 17, 28, 6, 19200.00),
(30, 17, 31, 2, 5000.00),
(31, 18, 36, 5, 11000.00),
(32, 18, 41, 3, 14400.00),
(33, 19, 8, 2, 10000.00),
(34, 19, 13, 1, 3000.00),
(35, 20, 18, 4, 12000.00),
(36, 20, 23, 2, 5600.00),
(37, 21, 33, 6, 21000.00),
(38, 21, 38, 2, 4000.00),
(39, 22, 43, 5, 22500.00),
(40, 22, 44, 3, 15000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `stock` int(11) NOT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre`, `precio`, `stock`, `id_categoria`, `id_proveedor`) VALUES
(1, 'Leche', 1.50, 100, 1, 1),
(2, 'Carne de res', 10.00, 50, 2, 2),
(3, 'Jugo de naranja', 2.00, 80, 3, 1),
(4, 'Pan integral', 1.20, 60, 4, 2),
(5, 'Leche Entera', 2.50, 100, 1, 1),
(6, 'Queso Cheddar', 4.80, 50, 1, 2),
(7, 'Yogur Natural', 3.20, 80, 1, 1),
(8, 'Mantequilla', 5.00, 40, 1, 2),
(9, 'Carne de Res', 12.50, 60, 2, 1),
(10, 'Pollo Entero', 9.90, 70, 2, 2),
(11, 'Chuletas de Cerdo', 11.80, 55, 2, 1),
(12, 'Salchichas', 6.50, 90, 2, 2),
(13, 'Jugo de Naranja', 3.00, 100, 3, 1),
(14, 'Gaseosa Cola', 2.20, 120, 3, 2),
(15, 'Agua Mineral', 1.50, 200, 3, 1),
(16, 'Té Verde', 3.80, 80, 3, 2),
(17, 'Pan Baguette', 2.30, 75, 4, 1),
(18, 'Pan Integral', 3.00, 60, 4, 2),
(19, 'Croissants', 4.20, 50, 4, 1),
(20, 'Bizcocho de Vainilla', 6.50, 40, 4, 2),
(21, 'Pescado Tilapia', 10.90, 50, 5, 1),
(22, 'Salmón Fresco', 15.40, 40, 5, 2),
(23, 'Atún en Lata', 2.80, 100, 5, 1),
(24, 'Camarones', 18.00, 30, 5, 2),
(25, 'Huevos Blancos', 3.50, 150, 6, 1),
(26, 'Huevos Orgánicos', 4.80, 100, 6, 2),
(27, 'Huevos de Codorniz', 2.50, 80, 6, 1),
(28, 'Frijoles Negros', 3.20, 90, 7, 1),
(29, 'Lentejas', 3.00, 100, 7, 2),
(30, 'Garbanzos', 2.90, 110, 7, 1),
(31, 'Arroz Blanco', 2.50, 200, 8, 1),
(32, 'Harina de Trigo', 3.00, 150, 8, 2),
(33, 'Avena en Hojuelas', 3.50, 120, 8, 1),
(34, 'Maíz en Grano', 2.80, 130, 8, 2),
(35, 'Zanahorias', 1.80, 180, 9, 1),
(36, 'Tomates', 2.20, 160, 9, 2),
(37, 'Lechuga Romana', 2.50, 140, 9, 1),
(38, 'Papas', 2.00, 200, 9, 2),
(39, 'Café Molido', 5.50, 100, 10, 1),
(40, 'Café en Grano', 6.20, 90, 10, 2),
(41, 'Capuchino Instantáneo', 4.80, 110, 10, 1),
(42, 'Espresso', 7.00, 80, 10, 2),
(43, 'Cacao en Polvo', 4.50, 100, 10, 1),
(44, 'Chocolate para Taza', 5.00, 90, 10, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `id_proveedor` int(11) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`id_proveedor`, `nombre`, `contacto`, `telefono`) VALUES
(1, 'Proveedor A', 'Juan Pérez', '123456789'),
(2, 'Proveedor B', 'María Gómez', '987654321');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ventas`
--

CREATE TABLE `ventas` (
  `id_venta` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `fecha` date NOT NULL,
  `total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ventas`
--

INSERT INTO `ventas` (`id_venta`, `id_cliente`, `fecha`, `total`) VALUES
(1, 1, '2024-03-03', 15.00),
(2, 2, '2024-03-03', 5.20),
(3, 1, '2024-03-01', 152000.00),
(4, 5, '2024-03-02', 98000.00),
(5, 3, '2024-03-03', 45000.00),
(6, 8, '2024-03-04', 125000.00),
(7, 6, '2024-03-05', 230000.00),
(8, 2, '2024-03-06', 175000.00),
(9, 10, '2024-03-07', 89000.00),
(10, 4, '2024-03-08', 62000.00),
(11, 7, '2024-03-09', 195000.00),
(12, 9, '2024-03-10', 112000.00),
(13, 11, '2024-03-11', 87000.00),
(14, 12, '2024-03-12', 134000.00),
(15, 14, '2024-03-13', 99000.00),
(16, 13, '2024-03-14', 256000.00),
(17, 15, '2024-03-15', 183000.00),
(18, 17, '2024-03-16', 67000.00),
(19, 16, '2024-03-17', 143000.00),
(20, 18, '2024-03-18', 76000.00),
(21, 19, '2024-03-19', 92000.00),
(22, 20, '2024-03-20', 110000.00),
(23, 21, '2024-03-21', 203000.00),
(24, 22, '2024-03-22', 142000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vista_productos_mas_vendidos as`
--

CREATE TABLE `vista_productos_mas_vendidos as` (
  `id_producto` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vista_productos_proveedores as`
--

CREATE TABLE `vista_productos_proveedores as` (
  `id_producto` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `precio` decimal(10,2) DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `id_categoria` int(11) DEFAULT NULL,
  `id_proveedor` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vista_proveedores_productos as`
--

CREATE TABLE `vista_proveedores_productos as` (
  `id_proveedor` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `contacto` varchar(100) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vista_ventas_clientes as`
--

CREATE TABLE `vista_ventas_clientes as` (
  `id_cliente` int(11) DEFAULT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `direccion` varchar(255) DEFAULT NULL,
  `telefono` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vista_ventas_con_productos as`
--

CREATE TABLE `vista_ventas_con_productos as` (
  `id_venta` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vista_ventas_por_fecha as`
--

CREATE TABLE `vista_ventas_por_fecha as` (
  `id_venta` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `fecha` date DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
